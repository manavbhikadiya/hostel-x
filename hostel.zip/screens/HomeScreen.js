import { NavigationContainer } from "@react-navigation/native";
import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  ScrollView,
} from "react-native";
import { TouchableOpacity } from "react-native-web";

const { width, height } = Dimensions.get("window");

const HomeScreen = ({navigation}) => {

  const goDetail = () =>{
    navigation.navigate('Details');
  }
  return (
    <>
      <View style={styles.HomeScreenContainer}>
        <View style={styles.header}>
          <View style={styles.menuIcon}>
            <Text>H</Text>
          </View>
          <View style={styles.profile}>
            <Image
              style={styles.profileImage}
              source={require("../assets/profile_1.jpeg")}
            />
          </View>
        </View>
        <View style={styles.screenBody}>
          <View style={styles.screenBodyTop}>
            <View style={styles.titles}>
              <Text style={styles.greet}>Hi, Niara</Text>
              <Text style={styles.screenHeading}>
                Enjoy your Staying with us
              </Text>
            </View>
            <View style={styles.searchFilterContainer}>
              <View style={styles.searchBar}>
                <Text style={styles.searchIcon}>H</Text>
                <Text style={styles.searchText}>Search</Text>
              </View>
              <View style={styles.filters}>
                <Text>HK</Text>
              </View>
            </View>
          </View>
          <View style={styles.hostelsListContainer}>
            <ScrollView
              horizontal={true}
              endFillColor="#fcfbfe"
              indicatorStyle="black"
              showsHorizontalScrollIndicator={false}
              snapToAlignment="center"
              overScrollMode="never"
            >
              <TouchableOpacity style={styles.hostelCard} onPress={()=>goDetail()} >
                <View style={styles.hostelImageContainer}>
                  <Image
                    style={styles.hostelImage}
                    source={require("../assets/hostel_1.jpg")}
                  />
                  <View style={styles.heartContainer}>
                    <Text style={styles.heartIcon}>H</Text>
                  </View>
                </View>
                <View style={styles.hostelDescription}>
                  <Text style={styles.hostelDescriptionText}>
                    Dreams Luxury Suites
                  </Text>
                  <View style={styles.locationPriceContainer}>
                    <View style={styles.location}>
                      <Text style={styles.locationImage}>L</Text>
                      <Text style={styles.locationText}>Vasad</Text>
                    </View>
                    <View style={styles.price}>
                      <Text style={styles.priceText}>$1890/year</Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
              <View style={styles.hostelCard}>
                <View style={styles.hostelImageContainer}>
                  <Image
                    style={styles.hostelImage}
                    source={require("../assets/hostel_2.jpg")}
                  />
                  <View style={styles.heartContainer}>
                    <Text style={styles.heartIcon}>H</Text>
                  </View>
                </View>
                <View style={styles.hostelDescription}>
                  <Text style={styles.hostelDescriptionText}>
                    Dreams Luxury Suites
                  </Text>
                  <View style={styles.locationPriceContainer}>
                    <View style={styles.location}>
                      <Text style={styles.locationImage}>L</Text>
                      <Text style={styles.locationText}>Vasad</Text>
                    </View>
                    <View style={styles.price}>
                      <Text style={styles.priceText}>$1890/year</Text>
                    </View>
                  </View>
                </View>
              </View>
            </ScrollView>
          </View>
          <View style={styles.nearBySectionContainer}>
            <View style={styles.NearByViewAll}>
              <Text style={styles.nearByText}>Nearby</Text>
              <Text style={styles.viewAllText}>View all </Text>
            </View>
            <View style={styles.nearbyCard}>
              <View style={styles.nearbyHostelImageContainer}>
                <Image style={styles.nearbyHostelImageContainer} source={require('../assets/hostel_1.jpg')} />
              </View>
              <View style={styles.nearBydescription}>
                <Text style={styles.hostelName}>Roayal Ambarrukmo</Text>
                <View style={[styles.locationPriceContainer,{marginTop:20}]}>
                  <View style={styles.location}>
                    <Text style={styles.locationImage}>L</Text>
                    <Text style={styles.locationText}>Vasad</Text>
                  </View>
                  <View style={styles.price}>
                    <Text style={styles.priceText}>$1890/year</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>
      </View>
    </>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  HomeScreenContainer: {
    flex: 1,
    backgroundColor: "#fcfbfe",
    paddingTop: 50,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 30,
  },
  menuIcon: {
    backgroundColor: "#fff",
    width: 50,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 15,
  },
  profile: {
    backgroundColor: "#fff",
    width: "auto",
    height: "auto",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "#ff8080",
    borderRadius: 50,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 50,
    display: "flex",
  },
  screenBody: {
    flex: 1,
    // backgroundColor: "red",
  },
  screenBodyTop: {
    paddingHorizontal: 30,
  },
  titles: {
    marginTop: 25,
  },
  greet: {
    fontSize: 17,
    fontStyle: "normal",
    color: "#232323",
  },
  screenHeading: {
    fontSize: 23,
    fontStyle: "normal",
    color: "#232323",
    fontWeight: "bold",
  },
  searchFilterContainer: {
    marginTop: 20,
    justifyContent: "space-between",
    flexDirection: "row",
  },
  searchBar: {
    width: width - 130,
    height: 50,
    backgroundColor: "#fff",
    borderRadius: 15,
    padding: 15,
    justifyContent: "flex-start",
    flexDirection: "row",
  },
  searchIcon: {
    color: "#bfbfbf",
  },
  searchText: {
    marginLeft: 10,
    color: "#bfbfbf",
  },
  filters: {
    backgroundColor: "#fff",
    width: 50,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 15,
  },
  hostelsListContainer: {
    marginTop: 30,
    backgroundColor: "#fcfbfe",
  },
  hostelCard: {
    width: 200,
    padding: 5,
    backgroundColor: "#fff",
    borderRadius: 20,
    margin: 20,
  },
  hostelImageContainer: {
    width: "auto",
    height: 200,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 20,
  },
  hostelImage: {
    width: 190,
    height: 200,
    borderRadius: 20,
  },
  heartContainer: {
    width: 40,
    height: 40,
    borderRadius: 50,
    backgroundColor: "rgba(255, 255, 255,0.7)",
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    top: 10,
    right: 10,
  },
  heartIcon: {
    zIndex: 1,
  },
  hostelDescription: {
    marginTop: 10,
    width: "auto",
    height: 50,
    alignItems: "center",
  },
  hostelDescriptionText: {
    color: "#232323",
    fontWeight: "bold",
    fontSize: 16,
  },
  locationPriceContainer: {
    marginTop: 5,
    flexDirection: "row",
    justifyContent: "space-between",
    width: "auto",
  },
  location: {
    flexDirection: "row",
  },
  locationImage: {},
  locationText: {
    color: "#bfbfbf",
    marginLeft: 10,
  },
  price: {
    //   backgroundColor:"orange"
  },
  priceText: {
    marginLeft: 40,
    fontSize: 14,
    fontWeight: "bold",
  },

  //Nearby section container
  nearBySectionContainer: {
    marginTop: 30,
    paddingHorizontal: 30,
  },
  NearByViewAll: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  nearByText: {
    fontSize: 23,
    fontStyle: "normal",
    color: "#232323",
    fontWeight: "bold",
  },
  viewAllText: {
    color: "#bfbfbf",
    fontSize: 16,
    fontStyle: "normal",
  },
  nearbyCard:{
      marginTop:25,
      flexDirection:"row",
      backgroundColor:"#fff",
      padding:5,
      borderRadius:20,
  },
  nearbyHostelImageContainer:{
      width:120,
      height:120,
      borderRadius:20,
      justifyContent:"center",
      alignItems:"center"
  },
  nearbyHostelImage:{
    width:120,
    height:120,
    borderRadius:20,
  },
  nearBydescription:{
      padding:10,
      marginLeft:10,
      borderRadius:20
  },
  hostelName:{
    fontSize: 18,
    fontStyle: "normal",
    color: "#232323",
    fontWeight: "bold",
  }
});
