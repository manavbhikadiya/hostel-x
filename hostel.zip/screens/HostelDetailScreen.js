import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  ScrollView,
  ImageBackground,
} from "react-native";
import { BlurView } from "expo-blur";

const { width, height } = Dimensions.get("screen");

const HostelDetailScreen = () => {
  return (
    <>
      <View style={styles.detailsScreenContainer}>
        <View style={styles.hostelImageContainer}>
          <View style={styles.hostelImage}>
            <ImageBackground
              style={styles.hImage}
              imageStyle={{ borderRadius: 20 }}
              source={require("../assets/hostel_1.jpg")}
            >
              <BlurView intensity={100} style={styles.hostelDescription}>
                <Text style={styles.hostelName}>Dreams Luxury Suites</Text>
                <Text style={styles.hostelLocation}>
                  Santorini Island, Greece
                </Text>
                <Text style={styles.price}>$1890/year</Text>
                <View style={styles.heartContainer}>
                  <Text>H</Text>
                </View>
              </BlurView>
            </ImageBackground>
          </View>
        </View>
        <View style={styles.NearByViewAll}>
          <Text style={styles.nearByText}>Facilities</Text>
          <Text style={styles.viewAllText}>View all </Text>
        </View>
      </View>
    </>
  );
};

export default HostelDetailScreen;
const styles = StyleSheet.create({
  detailsScreenContainer: {
    flex: 1,
    // backgroundColor: "red",
    paddingTop: 50,
  },
  hostelImageContainer: {
    justifyContent: "center",
    alignItems: "center",
  },
  hostelImage: {
    width: width - 50,
    height: height - 350,
    borderRadius: 20,
  },
  hImage: {
    width: width - 50,
    height: height - 350,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  hostelDescription: {
    position: "absolute",
    width: width - 80,
    height: 150,
    bottom: 20,
    borderRadius: 20,
    padding: 10,
  },
  hostelName: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 23,
    marginTop: 10,
  },
  hostelLocation: {
    color: "#f2f2f2",
    fontSize: 14,
    marginTop: 20,
  },
  price: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 17,
    marginTop: 10,
  },
  heartContainer: {
    width: 35,
    height: 35,
    borderRadius: 50,
    backgroundColor: "#ff8080",
    justifyContent: "center",
    alignItems: "center",
    position: "absolute",
    bottom: 10,
    right: 10,
  },
  NearByViewAll: {
    marginTop: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 30,
  },
  nearByText: {
    fontSize: 23,
    fontStyle: "normal",
    color: "#232323",
    fontWeight: "bold",
  },
  viewAllText: {
    color: "#bfbfbf",
    fontSize: 16,
    fontStyle: "normal",
  },
});
